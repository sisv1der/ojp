package com.openjproxy.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class StatementServiceGrpc {

  private StatementServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "com.openjproxy.grpc.StatementService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.ConnectionDetails,
      com.openjproxy.grpc.SessionInfo> getConnectMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "connect",
      requestType = com.openjproxy.grpc.ConnectionDetails.class,
      responseType = com.openjproxy.grpc.SessionInfo.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.ConnectionDetails,
      com.openjproxy.grpc.SessionInfo> getConnectMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.ConnectionDetails, com.openjproxy.grpc.SessionInfo> getConnectMethod;
    if ((getConnectMethod = StatementServiceGrpc.getConnectMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getConnectMethod = StatementServiceGrpc.getConnectMethod) == null) {
          StatementServiceGrpc.getConnectMethod = getConnectMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.ConnectionDetails, com.openjproxy.grpc.SessionInfo>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "connect"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.ConnectionDetails.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("connect"))
              .build();
        }
      }
    }
    return getConnectMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest,
      com.openjproxy.grpc.OpResult> getExecuteUpdateMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "executeUpdate",
      requestType = com.openjproxy.grpc.StatementRequest.class,
      responseType = com.openjproxy.grpc.OpResult.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest,
      com.openjproxy.grpc.OpResult> getExecuteUpdateMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest, com.openjproxy.grpc.OpResult> getExecuteUpdateMethod;
    if ((getExecuteUpdateMethod = StatementServiceGrpc.getExecuteUpdateMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getExecuteUpdateMethod = StatementServiceGrpc.getExecuteUpdateMethod) == null) {
          StatementServiceGrpc.getExecuteUpdateMethod = getExecuteUpdateMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.StatementRequest, com.openjproxy.grpc.OpResult>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "executeUpdate"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.StatementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.OpResult.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("executeUpdate"))
              .build();
        }
      }
    }
    return getExecuteUpdateMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest,
      com.openjproxy.grpc.OpResult> getExecuteQueryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "executeQuery",
      requestType = com.openjproxy.grpc.StatementRequest.class,
      responseType = com.openjproxy.grpc.OpResult.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest,
      com.openjproxy.grpc.OpResult> getExecuteQueryMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.StatementRequest, com.openjproxy.grpc.OpResult> getExecuteQueryMethod;
    if ((getExecuteQueryMethod = StatementServiceGrpc.getExecuteQueryMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getExecuteQueryMethod = StatementServiceGrpc.getExecuteQueryMethod) == null) {
          StatementServiceGrpc.getExecuteQueryMethod = getExecuteQueryMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.StatementRequest, com.openjproxy.grpc.OpResult>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "executeQuery"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.StatementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.OpResult.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("executeQuery"))
              .build();
        }
      }
    }
    return getExecuteQueryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.ResultSetFetchRequest,
      com.openjproxy.grpc.OpResult> getFetchNextRowsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "fetchNextRows",
      requestType = com.openjproxy.grpc.ResultSetFetchRequest.class,
      responseType = com.openjproxy.grpc.OpResult.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.ResultSetFetchRequest,
      com.openjproxy.grpc.OpResult> getFetchNextRowsMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.ResultSetFetchRequest, com.openjproxy.grpc.OpResult> getFetchNextRowsMethod;
    if ((getFetchNextRowsMethod = StatementServiceGrpc.getFetchNextRowsMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getFetchNextRowsMethod = StatementServiceGrpc.getFetchNextRowsMethod) == null) {
          StatementServiceGrpc.getFetchNextRowsMethod = getFetchNextRowsMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.ResultSetFetchRequest, com.openjproxy.grpc.OpResult>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "fetchNextRows"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.ResultSetFetchRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.OpResult.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("fetchNextRows"))
              .build();
        }
      }
    }
    return getFetchNextRowsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.LobDataBlock,
      com.openjproxy.grpc.LobReference> getCreateLobMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "createLob",
      requestType = com.openjproxy.grpc.LobDataBlock.class,
      responseType = com.openjproxy.grpc.LobReference.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.LobDataBlock,
      com.openjproxy.grpc.LobReference> getCreateLobMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.LobDataBlock, com.openjproxy.grpc.LobReference> getCreateLobMethod;
    if ((getCreateLobMethod = StatementServiceGrpc.getCreateLobMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getCreateLobMethod = StatementServiceGrpc.getCreateLobMethod) == null) {
          StatementServiceGrpc.getCreateLobMethod = getCreateLobMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.LobDataBlock, com.openjproxy.grpc.LobReference>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "createLob"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.LobDataBlock.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.LobReference.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("createLob"))
              .build();
        }
      }
    }
    return getCreateLobMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.ReadLobRequest,
      com.openjproxy.grpc.LobDataBlock> getReadLobMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "readLob",
      requestType = com.openjproxy.grpc.ReadLobRequest.class,
      responseType = com.openjproxy.grpc.LobDataBlock.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.ReadLobRequest,
      com.openjproxy.grpc.LobDataBlock> getReadLobMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.ReadLobRequest, com.openjproxy.grpc.LobDataBlock> getReadLobMethod;
    if ((getReadLobMethod = StatementServiceGrpc.getReadLobMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getReadLobMethod = StatementServiceGrpc.getReadLobMethod) == null) {
          StatementServiceGrpc.getReadLobMethod = getReadLobMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.ReadLobRequest, com.openjproxy.grpc.LobDataBlock>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "readLob"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.ReadLobRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.LobDataBlock.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("readLob"))
              .build();
        }
      }
    }
    return getReadLobMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionTerminationStatus> getTerminateSessionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "terminateSession",
      requestType = com.openjproxy.grpc.SessionInfo.class,
      responseType = com.openjproxy.grpc.SessionTerminationStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionTerminationStatus> getTerminateSessionMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionTerminationStatus> getTerminateSessionMethod;
    if ((getTerminateSessionMethod = StatementServiceGrpc.getTerminateSessionMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getTerminateSessionMethod = StatementServiceGrpc.getTerminateSessionMethod) == null) {
          StatementServiceGrpc.getTerminateSessionMethod = getTerminateSessionMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionTerminationStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "terminateSession"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionTerminationStatus.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("terminateSession"))
              .build();
        }
      }
    }
    return getTerminateSessionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getStartTransactionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "startTransaction",
      requestType = com.openjproxy.grpc.SessionInfo.class,
      responseType = com.openjproxy.grpc.SessionInfo.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getStartTransactionMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo> getStartTransactionMethod;
    if ((getStartTransactionMethod = StatementServiceGrpc.getStartTransactionMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getStartTransactionMethod = StatementServiceGrpc.getStartTransactionMethod) == null) {
          StatementServiceGrpc.getStartTransactionMethod = getStartTransactionMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "startTransaction"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("startTransaction"))
              .build();
        }
      }
    }
    return getStartTransactionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getCommitTransactionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "commitTransaction",
      requestType = com.openjproxy.grpc.SessionInfo.class,
      responseType = com.openjproxy.grpc.SessionInfo.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getCommitTransactionMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo> getCommitTransactionMethod;
    if ((getCommitTransactionMethod = StatementServiceGrpc.getCommitTransactionMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getCommitTransactionMethod = StatementServiceGrpc.getCommitTransactionMethod) == null) {
          StatementServiceGrpc.getCommitTransactionMethod = getCommitTransactionMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "commitTransaction"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("commitTransaction"))
              .build();
        }
      }
    }
    return getCommitTransactionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getRollbackTransactionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "rollbackTransaction",
      requestType = com.openjproxy.grpc.SessionInfo.class,
      responseType = com.openjproxy.grpc.SessionInfo.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo,
      com.openjproxy.grpc.SessionInfo> getRollbackTransactionMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo> getRollbackTransactionMethod;
    if ((getRollbackTransactionMethod = StatementServiceGrpc.getRollbackTransactionMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getRollbackTransactionMethod = StatementServiceGrpc.getRollbackTransactionMethod) == null) {
          StatementServiceGrpc.getRollbackTransactionMethod = getRollbackTransactionMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.SessionInfo, com.openjproxy.grpc.SessionInfo>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "rollbackTransaction"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.SessionInfo.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("rollbackTransaction"))
              .build();
        }
      }
    }
    return getRollbackTransactionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.CallResourceRequest,
      com.openjproxy.grpc.CallResourceResponse> getCallResourceMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "callResource",
      requestType = com.openjproxy.grpc.CallResourceRequest.class,
      responseType = com.openjproxy.grpc.CallResourceResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.CallResourceRequest,
      com.openjproxy.grpc.CallResourceResponse> getCallResourceMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.CallResourceRequest, com.openjproxy.grpc.CallResourceResponse> getCallResourceMethod;
    if ((getCallResourceMethod = StatementServiceGrpc.getCallResourceMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getCallResourceMethod = StatementServiceGrpc.getCallResourceMethod) == null) {
          StatementServiceGrpc.getCallResourceMethod = getCallResourceMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.CallResourceRequest, com.openjproxy.grpc.CallResourceResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "callResource"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.CallResourceRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.CallResourceResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("callResource"))
              .build();
        }
      }
    }
    return getCallResourceMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaStartRequest,
      com.openjproxy.grpc.XaResponse> getXaStartMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaStart",
      requestType = com.openjproxy.grpc.XaStartRequest.class,
      responseType = com.openjproxy.grpc.XaResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaStartRequest,
      com.openjproxy.grpc.XaResponse> getXaStartMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaStartRequest, com.openjproxy.grpc.XaResponse> getXaStartMethod;
    if ((getXaStartMethod = StatementServiceGrpc.getXaStartMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaStartMethod = StatementServiceGrpc.getXaStartMethod) == null) {
          StatementServiceGrpc.getXaStartMethod = getXaStartMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaStartRequest, com.openjproxy.grpc.XaResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaStart"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaStartRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaStart"))
              .build();
        }
      }
    }
    return getXaStartMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaEndRequest,
      com.openjproxy.grpc.XaResponse> getXaEndMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaEnd",
      requestType = com.openjproxy.grpc.XaEndRequest.class,
      responseType = com.openjproxy.grpc.XaResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaEndRequest,
      com.openjproxy.grpc.XaResponse> getXaEndMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaEndRequest, com.openjproxy.grpc.XaResponse> getXaEndMethod;
    if ((getXaEndMethod = StatementServiceGrpc.getXaEndMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaEndMethod = StatementServiceGrpc.getXaEndMethod) == null) {
          StatementServiceGrpc.getXaEndMethod = getXaEndMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaEndRequest, com.openjproxy.grpc.XaResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaEnd"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaEndRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaEnd"))
              .build();
        }
      }
    }
    return getXaEndMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaPrepareRequest,
      com.openjproxy.grpc.XaPrepareResponse> getXaPrepareMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaPrepare",
      requestType = com.openjproxy.grpc.XaPrepareRequest.class,
      responseType = com.openjproxy.grpc.XaPrepareResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaPrepareRequest,
      com.openjproxy.grpc.XaPrepareResponse> getXaPrepareMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaPrepareRequest, com.openjproxy.grpc.XaPrepareResponse> getXaPrepareMethod;
    if ((getXaPrepareMethod = StatementServiceGrpc.getXaPrepareMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaPrepareMethod = StatementServiceGrpc.getXaPrepareMethod) == null) {
          StatementServiceGrpc.getXaPrepareMethod = getXaPrepareMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaPrepareRequest, com.openjproxy.grpc.XaPrepareResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaPrepare"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaPrepareRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaPrepareResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaPrepare"))
              .build();
        }
      }
    }
    return getXaPrepareMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaCommitRequest,
      com.openjproxy.grpc.XaResponse> getXaCommitMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaCommit",
      requestType = com.openjproxy.grpc.XaCommitRequest.class,
      responseType = com.openjproxy.grpc.XaResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaCommitRequest,
      com.openjproxy.grpc.XaResponse> getXaCommitMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaCommitRequest, com.openjproxy.grpc.XaResponse> getXaCommitMethod;
    if ((getXaCommitMethod = StatementServiceGrpc.getXaCommitMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaCommitMethod = StatementServiceGrpc.getXaCommitMethod) == null) {
          StatementServiceGrpc.getXaCommitMethod = getXaCommitMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaCommitRequest, com.openjproxy.grpc.XaResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaCommit"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaCommitRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaCommit"))
              .build();
        }
      }
    }
    return getXaCommitMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRollbackRequest,
      com.openjproxy.grpc.XaResponse> getXaRollbackMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaRollback",
      requestType = com.openjproxy.grpc.XaRollbackRequest.class,
      responseType = com.openjproxy.grpc.XaResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRollbackRequest,
      com.openjproxy.grpc.XaResponse> getXaRollbackMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRollbackRequest, com.openjproxy.grpc.XaResponse> getXaRollbackMethod;
    if ((getXaRollbackMethod = StatementServiceGrpc.getXaRollbackMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaRollbackMethod = StatementServiceGrpc.getXaRollbackMethod) == null) {
          StatementServiceGrpc.getXaRollbackMethod = getXaRollbackMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaRollbackRequest, com.openjproxy.grpc.XaResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaRollback"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaRollbackRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaRollback"))
              .build();
        }
      }
    }
    return getXaRollbackMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRecoverRequest,
      com.openjproxy.grpc.XaRecoverResponse> getXaRecoverMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaRecover",
      requestType = com.openjproxy.grpc.XaRecoverRequest.class,
      responseType = com.openjproxy.grpc.XaRecoverResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRecoverRequest,
      com.openjproxy.grpc.XaRecoverResponse> getXaRecoverMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaRecoverRequest, com.openjproxy.grpc.XaRecoverResponse> getXaRecoverMethod;
    if ((getXaRecoverMethod = StatementServiceGrpc.getXaRecoverMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaRecoverMethod = StatementServiceGrpc.getXaRecoverMethod) == null) {
          StatementServiceGrpc.getXaRecoverMethod = getXaRecoverMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaRecoverRequest, com.openjproxy.grpc.XaRecoverResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaRecover"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaRecoverRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaRecoverResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaRecover"))
              .build();
        }
      }
    }
    return getXaRecoverMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaForgetRequest,
      com.openjproxy.grpc.XaResponse> getXaForgetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaForget",
      requestType = com.openjproxy.grpc.XaForgetRequest.class,
      responseType = com.openjproxy.grpc.XaResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaForgetRequest,
      com.openjproxy.grpc.XaResponse> getXaForgetMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaForgetRequest, com.openjproxy.grpc.XaResponse> getXaForgetMethod;
    if ((getXaForgetMethod = StatementServiceGrpc.getXaForgetMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaForgetMethod = StatementServiceGrpc.getXaForgetMethod) == null) {
          StatementServiceGrpc.getXaForgetMethod = getXaForgetMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaForgetRequest, com.openjproxy.grpc.XaResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaForget"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaForgetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaForget"))
              .build();
        }
      }
    }
    return getXaForgetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaSetTransactionTimeoutRequest,
      com.openjproxy.grpc.XaSetTransactionTimeoutResponse> getXaSetTransactionTimeoutMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaSetTransactionTimeout",
      requestType = com.openjproxy.grpc.XaSetTransactionTimeoutRequest.class,
      responseType = com.openjproxy.grpc.XaSetTransactionTimeoutResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaSetTransactionTimeoutRequest,
      com.openjproxy.grpc.XaSetTransactionTimeoutResponse> getXaSetTransactionTimeoutMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaSetTransactionTimeoutRequest, com.openjproxy.grpc.XaSetTransactionTimeoutResponse> getXaSetTransactionTimeoutMethod;
    if ((getXaSetTransactionTimeoutMethod = StatementServiceGrpc.getXaSetTransactionTimeoutMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaSetTransactionTimeoutMethod = StatementServiceGrpc.getXaSetTransactionTimeoutMethod) == null) {
          StatementServiceGrpc.getXaSetTransactionTimeoutMethod = getXaSetTransactionTimeoutMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaSetTransactionTimeoutRequest, com.openjproxy.grpc.XaSetTransactionTimeoutResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaSetTransactionTimeout"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaSetTransactionTimeoutRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaSetTransactionTimeoutResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaSetTransactionTimeout"))
              .build();
        }
      }
    }
    return getXaSetTransactionTimeoutMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaGetTransactionTimeoutRequest,
      com.openjproxy.grpc.XaGetTransactionTimeoutResponse> getXaGetTransactionTimeoutMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaGetTransactionTimeout",
      requestType = com.openjproxy.grpc.XaGetTransactionTimeoutRequest.class,
      responseType = com.openjproxy.grpc.XaGetTransactionTimeoutResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaGetTransactionTimeoutRequest,
      com.openjproxy.grpc.XaGetTransactionTimeoutResponse> getXaGetTransactionTimeoutMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaGetTransactionTimeoutRequest, com.openjproxy.grpc.XaGetTransactionTimeoutResponse> getXaGetTransactionTimeoutMethod;
    if ((getXaGetTransactionTimeoutMethod = StatementServiceGrpc.getXaGetTransactionTimeoutMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaGetTransactionTimeoutMethod = StatementServiceGrpc.getXaGetTransactionTimeoutMethod) == null) {
          StatementServiceGrpc.getXaGetTransactionTimeoutMethod = getXaGetTransactionTimeoutMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaGetTransactionTimeoutRequest, com.openjproxy.grpc.XaGetTransactionTimeoutResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaGetTransactionTimeout"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaGetTransactionTimeoutRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaGetTransactionTimeoutResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaGetTransactionTimeout"))
              .build();
        }
      }
    }
    return getXaGetTransactionTimeoutMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.openjproxy.grpc.XaIsSameRMRequest,
      com.openjproxy.grpc.XaIsSameRMResponse> getXaIsSameRMMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "xaIsSameRM",
      requestType = com.openjproxy.grpc.XaIsSameRMRequest.class,
      responseType = com.openjproxy.grpc.XaIsSameRMResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.openjproxy.grpc.XaIsSameRMRequest,
      com.openjproxy.grpc.XaIsSameRMResponse> getXaIsSameRMMethod() {
    io.grpc.MethodDescriptor<com.openjproxy.grpc.XaIsSameRMRequest, com.openjproxy.grpc.XaIsSameRMResponse> getXaIsSameRMMethod;
    if ((getXaIsSameRMMethod = StatementServiceGrpc.getXaIsSameRMMethod) == null) {
      synchronized (StatementServiceGrpc.class) {
        if ((getXaIsSameRMMethod = StatementServiceGrpc.getXaIsSameRMMethod) == null) {
          StatementServiceGrpc.getXaIsSameRMMethod = getXaIsSameRMMethod =
              io.grpc.MethodDescriptor.<com.openjproxy.grpc.XaIsSameRMRequest, com.openjproxy.grpc.XaIsSameRMResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "xaIsSameRM"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaIsSameRMRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.openjproxy.grpc.XaIsSameRMResponse.getDefaultInstance()))
              .setSchemaDescriptor(new StatementServiceMethodDescriptorSupplier("xaIsSameRM"))
              .build();
        }
      }
    }
    return getXaIsSameRMMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static StatementServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<StatementServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<StatementServiceStub>() {
        @java.lang.Override
        public StatementServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new StatementServiceStub(channel, callOptions);
        }
      };
    return StatementServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static StatementServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<StatementServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<StatementServiceBlockingV2Stub>() {
        @java.lang.Override
        public StatementServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new StatementServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return StatementServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static StatementServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<StatementServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<StatementServiceBlockingStub>() {
        @java.lang.Override
        public StatementServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new StatementServiceBlockingStub(channel, callOptions);
        }
      };
    return StatementServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static StatementServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<StatementServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<StatementServiceFutureStub>() {
        @java.lang.Override
        public StatementServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new StatementServiceFutureStub(channel, callOptions);
        }
      };
    return StatementServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void connect(com.openjproxy.grpc.ConnectionDetails request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getConnectMethod(), responseObserver);
    }

    /**
     */
    default void executeUpdate(com.openjproxy.grpc.StatementRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExecuteUpdateMethod(), responseObserver);
    }

    /**
     */
    default void executeQuery(com.openjproxy.grpc.StatementRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExecuteQueryMethod(), responseObserver);
    }

    /**
     */
    default void fetchNextRows(com.openjproxy.grpc.ResultSetFetchRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getFetchNextRowsMethod(), responseObserver);
    }

    /**
     */
    default io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobDataBlock> createLob(
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobReference> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getCreateLobMethod(), responseObserver);
    }

    /**
     */
    default void readLob(com.openjproxy.grpc.ReadLobRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobDataBlock> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReadLobMethod(), responseObserver);
    }

    /**
     */
    default void terminateSession(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionTerminationStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTerminateSessionMethod(), responseObserver);
    }

    /**
     */
    default void startTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStartTransactionMethod(), responseObserver);
    }

    /**
     */
    default void commitTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCommitTransactionMethod(), responseObserver);
    }

    /**
     */
    default void rollbackTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRollbackTransactionMethod(), responseObserver);
    }

    /**
     */
    default void callResource(com.openjproxy.grpc.CallResourceRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.CallResourceResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCallResourceMethod(), responseObserver);
    }

    /**
     * <pre>
     * XA Transaction Operations
     * </pre>
     */
    default void xaStart(com.openjproxy.grpc.XaStartRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaStartMethod(), responseObserver);
    }

    /**
     */
    default void xaEnd(com.openjproxy.grpc.XaEndRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaEndMethod(), responseObserver);
    }

    /**
     */
    default void xaPrepare(com.openjproxy.grpc.XaPrepareRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaPrepareResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaPrepareMethod(), responseObserver);
    }

    /**
     */
    default void xaCommit(com.openjproxy.grpc.XaCommitRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaCommitMethod(), responseObserver);
    }

    /**
     */
    default void xaRollback(com.openjproxy.grpc.XaRollbackRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaRollbackMethod(), responseObserver);
    }

    /**
     */
    default void xaRecover(com.openjproxy.grpc.XaRecoverRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaRecoverResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaRecoverMethod(), responseObserver);
    }

    /**
     */
    default void xaForget(com.openjproxy.grpc.XaForgetRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaForgetMethod(), responseObserver);
    }

    /**
     */
    default void xaSetTransactionTimeout(com.openjproxy.grpc.XaSetTransactionTimeoutRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaSetTransactionTimeoutResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaSetTransactionTimeoutMethod(), responseObserver);
    }

    /**
     */
    default void xaGetTransactionTimeout(com.openjproxy.grpc.XaGetTransactionTimeoutRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaGetTransactionTimeoutResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaGetTransactionTimeoutMethod(), responseObserver);
    }

    /**
     */
    default void xaIsSameRM(com.openjproxy.grpc.XaIsSameRMRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaIsSameRMResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getXaIsSameRMMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service StatementService.
   */
  public static abstract class StatementServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return StatementServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service StatementService.
   */
  public static final class StatementServiceStub
      extends io.grpc.stub.AbstractAsyncStub<StatementServiceStub> {
    private StatementServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StatementServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new StatementServiceStub(channel, callOptions);
    }

    /**
     */
    public void connect(com.openjproxy.grpc.ConnectionDetails request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getConnectMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void executeUpdate(com.openjproxy.grpc.StatementRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExecuteUpdateMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void executeQuery(com.openjproxy.grpc.StatementRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getExecuteQueryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void fetchNextRows(com.openjproxy.grpc.ResultSetFetchRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getFetchNextRowsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobDataBlock> createLob(
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobReference> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getCreateLobMethod(), getCallOptions()), responseObserver);
    }

    /**
     */
    public void readLob(com.openjproxy.grpc.ReadLobRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobDataBlock> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getReadLobMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void terminateSession(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionTerminationStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getTerminateSessionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void startTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStartTransactionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void commitTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCommitTransactionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void rollbackTransaction(com.openjproxy.grpc.SessionInfo request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRollbackTransactionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void callResource(com.openjproxy.grpc.CallResourceRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.CallResourceResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCallResourceMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * XA Transaction Operations
     * </pre>
     */
    public void xaStart(com.openjproxy.grpc.XaStartRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaStartMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaEnd(com.openjproxy.grpc.XaEndRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaEndMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaPrepare(com.openjproxy.grpc.XaPrepareRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaPrepareResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaPrepareMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaCommit(com.openjproxy.grpc.XaCommitRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaCommitMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaRollback(com.openjproxy.grpc.XaRollbackRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaRollbackMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaRecover(com.openjproxy.grpc.XaRecoverRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaRecoverResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaRecoverMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaForget(com.openjproxy.grpc.XaForgetRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaForgetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaSetTransactionTimeout(com.openjproxy.grpc.XaSetTransactionTimeoutRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaSetTransactionTimeoutResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaSetTransactionTimeoutMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaGetTransactionTimeout(com.openjproxy.grpc.XaGetTransactionTimeoutRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaGetTransactionTimeoutResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaGetTransactionTimeoutMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void xaIsSameRM(com.openjproxy.grpc.XaIsSameRMRequest request,
        io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaIsSameRMResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getXaIsSameRMMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service StatementService.
   */
  public static final class StatementServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<StatementServiceBlockingV2Stub> {
    private StatementServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StatementServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new StatementServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo connect(com.openjproxy.grpc.ConnectionDetails request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getConnectMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.OpResult executeUpdate(com.openjproxy.grpc.StatementRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getExecuteUpdateMethod(), getCallOptions(), request);
    }

    /**
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.openjproxy.grpc.OpResult>
        executeQuery(com.openjproxy.grpc.StatementRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getExecuteQueryMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.OpResult fetchNextRows(com.openjproxy.grpc.ResultSetFetchRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getFetchNextRowsMethod(), getCallOptions(), request);
    }

    /**
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<com.openjproxy.grpc.LobDataBlock, com.openjproxy.grpc.LobReference>
        createLob() {
      return io.grpc.stub.ClientCalls.blockingBidiStreamingCall(
          getChannel(), getCreateLobMethod(), getCallOptions());
    }

    /**
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.openjproxy.grpc.LobDataBlock>
        readLob(com.openjproxy.grpc.ReadLobRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getReadLobMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionTerminationStatus terminateSession(com.openjproxy.grpc.SessionInfo request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getTerminateSessionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo startTransaction(com.openjproxy.grpc.SessionInfo request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getStartTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo commitTransaction(com.openjproxy.grpc.SessionInfo request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCommitTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo rollbackTransaction(com.openjproxy.grpc.SessionInfo request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getRollbackTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.CallResourceResponse callResource(com.openjproxy.grpc.CallResourceRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCallResourceMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * XA Transaction Operations
     * </pre>
     */
    public com.openjproxy.grpc.XaResponse xaStart(com.openjproxy.grpc.XaStartRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaStartMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaEnd(com.openjproxy.grpc.XaEndRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaEndMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaPrepareResponse xaPrepare(com.openjproxy.grpc.XaPrepareRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaPrepareMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaCommit(com.openjproxy.grpc.XaCommitRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaRollback(com.openjproxy.grpc.XaRollbackRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaRollbackMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaRecoverResponse xaRecover(com.openjproxy.grpc.XaRecoverRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaRecoverMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaForget(com.openjproxy.grpc.XaForgetRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaForgetMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaSetTransactionTimeoutResponse xaSetTransactionTimeout(com.openjproxy.grpc.XaSetTransactionTimeoutRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaSetTransactionTimeoutMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaGetTransactionTimeoutResponse xaGetTransactionTimeout(com.openjproxy.grpc.XaGetTransactionTimeoutRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaGetTransactionTimeoutMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaIsSameRMResponse xaIsSameRM(com.openjproxy.grpc.XaIsSameRMRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getXaIsSameRMMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service StatementService.
   */
  public static final class StatementServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<StatementServiceBlockingStub> {
    private StatementServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StatementServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new StatementServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo connect(com.openjproxy.grpc.ConnectionDetails request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getConnectMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.OpResult executeUpdate(com.openjproxy.grpc.StatementRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExecuteUpdateMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.openjproxy.grpc.OpResult> executeQuery(
        com.openjproxy.grpc.StatementRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getExecuteQueryMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.OpResult fetchNextRows(com.openjproxy.grpc.ResultSetFetchRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getFetchNextRowsMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.openjproxy.grpc.LobDataBlock> readLob(
        com.openjproxy.grpc.ReadLobRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getReadLobMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionTerminationStatus terminateSession(com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getTerminateSessionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo startTransaction(com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStartTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo commitTransaction(com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCommitTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.SessionInfo rollbackTransaction(com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRollbackTransactionMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.CallResourceResponse callResource(com.openjproxy.grpc.CallResourceRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCallResourceMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * XA Transaction Operations
     * </pre>
     */
    public com.openjproxy.grpc.XaResponse xaStart(com.openjproxy.grpc.XaStartRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaStartMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaEnd(com.openjproxy.grpc.XaEndRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaEndMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaPrepareResponse xaPrepare(com.openjproxy.grpc.XaPrepareRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaPrepareMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaCommit(com.openjproxy.grpc.XaCommitRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaCommitMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaRollback(com.openjproxy.grpc.XaRollbackRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaRollbackMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaRecoverResponse xaRecover(com.openjproxy.grpc.XaRecoverRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaRecoverMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaResponse xaForget(com.openjproxy.grpc.XaForgetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaForgetMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaSetTransactionTimeoutResponse xaSetTransactionTimeout(com.openjproxy.grpc.XaSetTransactionTimeoutRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaSetTransactionTimeoutMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaGetTransactionTimeoutResponse xaGetTransactionTimeout(com.openjproxy.grpc.XaGetTransactionTimeoutRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaGetTransactionTimeoutMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.openjproxy.grpc.XaIsSameRMResponse xaIsSameRM(com.openjproxy.grpc.XaIsSameRMRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getXaIsSameRMMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service StatementService.
   */
  public static final class StatementServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<StatementServiceFutureStub> {
    private StatementServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected StatementServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new StatementServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.SessionInfo> connect(
        com.openjproxy.grpc.ConnectionDetails request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getConnectMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.OpResult> executeUpdate(
        com.openjproxy.grpc.StatementRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExecuteUpdateMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.OpResult> fetchNextRows(
        com.openjproxy.grpc.ResultSetFetchRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getFetchNextRowsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.SessionTerminationStatus> terminateSession(
        com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getTerminateSessionMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.SessionInfo> startTransaction(
        com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStartTransactionMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.SessionInfo> commitTransaction(
        com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCommitTransactionMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.SessionInfo> rollbackTransaction(
        com.openjproxy.grpc.SessionInfo request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRollbackTransactionMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.CallResourceResponse> callResource(
        com.openjproxy.grpc.CallResourceRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCallResourceMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * XA Transaction Operations
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaResponse> xaStart(
        com.openjproxy.grpc.XaStartRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaStartMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaResponse> xaEnd(
        com.openjproxy.grpc.XaEndRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaEndMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaPrepareResponse> xaPrepare(
        com.openjproxy.grpc.XaPrepareRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaPrepareMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaResponse> xaCommit(
        com.openjproxy.grpc.XaCommitRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaCommitMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaResponse> xaRollback(
        com.openjproxy.grpc.XaRollbackRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaRollbackMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaRecoverResponse> xaRecover(
        com.openjproxy.grpc.XaRecoverRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaRecoverMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaResponse> xaForget(
        com.openjproxy.grpc.XaForgetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaForgetMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaSetTransactionTimeoutResponse> xaSetTransactionTimeout(
        com.openjproxy.grpc.XaSetTransactionTimeoutRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaSetTransactionTimeoutMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaGetTransactionTimeoutResponse> xaGetTransactionTimeout(
        com.openjproxy.grpc.XaGetTransactionTimeoutRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaGetTransactionTimeoutMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.openjproxy.grpc.XaIsSameRMResponse> xaIsSameRM(
        com.openjproxy.grpc.XaIsSameRMRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getXaIsSameRMMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CONNECT = 0;
  private static final int METHODID_EXECUTE_UPDATE = 1;
  private static final int METHODID_EXECUTE_QUERY = 2;
  private static final int METHODID_FETCH_NEXT_ROWS = 3;
  private static final int METHODID_READ_LOB = 4;
  private static final int METHODID_TERMINATE_SESSION = 5;
  private static final int METHODID_START_TRANSACTION = 6;
  private static final int METHODID_COMMIT_TRANSACTION = 7;
  private static final int METHODID_ROLLBACK_TRANSACTION = 8;
  private static final int METHODID_CALL_RESOURCE = 9;
  private static final int METHODID_XA_START = 10;
  private static final int METHODID_XA_END = 11;
  private static final int METHODID_XA_PREPARE = 12;
  private static final int METHODID_XA_COMMIT = 13;
  private static final int METHODID_XA_ROLLBACK = 14;
  private static final int METHODID_XA_RECOVER = 15;
  private static final int METHODID_XA_FORGET = 16;
  private static final int METHODID_XA_SET_TRANSACTION_TIMEOUT = 17;
  private static final int METHODID_XA_GET_TRANSACTION_TIMEOUT = 18;
  private static final int METHODID_XA_IS_SAME_RM = 19;
  private static final int METHODID_CREATE_LOB = 20;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CONNECT:
          serviceImpl.connect((com.openjproxy.grpc.ConnectionDetails) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo>) responseObserver);
          break;
        case METHODID_EXECUTE_UPDATE:
          serviceImpl.executeUpdate((com.openjproxy.grpc.StatementRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult>) responseObserver);
          break;
        case METHODID_EXECUTE_QUERY:
          serviceImpl.executeQuery((com.openjproxy.grpc.StatementRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult>) responseObserver);
          break;
        case METHODID_FETCH_NEXT_ROWS:
          serviceImpl.fetchNextRows((com.openjproxy.grpc.ResultSetFetchRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.OpResult>) responseObserver);
          break;
        case METHODID_READ_LOB:
          serviceImpl.readLob((com.openjproxy.grpc.ReadLobRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobDataBlock>) responseObserver);
          break;
        case METHODID_TERMINATE_SESSION:
          serviceImpl.terminateSession((com.openjproxy.grpc.SessionInfo) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionTerminationStatus>) responseObserver);
          break;
        case METHODID_START_TRANSACTION:
          serviceImpl.startTransaction((com.openjproxy.grpc.SessionInfo) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo>) responseObserver);
          break;
        case METHODID_COMMIT_TRANSACTION:
          serviceImpl.commitTransaction((com.openjproxy.grpc.SessionInfo) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo>) responseObserver);
          break;
        case METHODID_ROLLBACK_TRANSACTION:
          serviceImpl.rollbackTransaction((com.openjproxy.grpc.SessionInfo) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.SessionInfo>) responseObserver);
          break;
        case METHODID_CALL_RESOURCE:
          serviceImpl.callResource((com.openjproxy.grpc.CallResourceRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.CallResourceResponse>) responseObserver);
          break;
        case METHODID_XA_START:
          serviceImpl.xaStart((com.openjproxy.grpc.XaStartRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse>) responseObserver);
          break;
        case METHODID_XA_END:
          serviceImpl.xaEnd((com.openjproxy.grpc.XaEndRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse>) responseObserver);
          break;
        case METHODID_XA_PREPARE:
          serviceImpl.xaPrepare((com.openjproxy.grpc.XaPrepareRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaPrepareResponse>) responseObserver);
          break;
        case METHODID_XA_COMMIT:
          serviceImpl.xaCommit((com.openjproxy.grpc.XaCommitRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse>) responseObserver);
          break;
        case METHODID_XA_ROLLBACK:
          serviceImpl.xaRollback((com.openjproxy.grpc.XaRollbackRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse>) responseObserver);
          break;
        case METHODID_XA_RECOVER:
          serviceImpl.xaRecover((com.openjproxy.grpc.XaRecoverRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaRecoverResponse>) responseObserver);
          break;
        case METHODID_XA_FORGET:
          serviceImpl.xaForget((com.openjproxy.grpc.XaForgetRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaResponse>) responseObserver);
          break;
        case METHODID_XA_SET_TRANSACTION_TIMEOUT:
          serviceImpl.xaSetTransactionTimeout((com.openjproxy.grpc.XaSetTransactionTimeoutRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaSetTransactionTimeoutResponse>) responseObserver);
          break;
        case METHODID_XA_GET_TRANSACTION_TIMEOUT:
          serviceImpl.xaGetTransactionTimeout((com.openjproxy.grpc.XaGetTransactionTimeoutRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaGetTransactionTimeoutResponse>) responseObserver);
          break;
        case METHODID_XA_IS_SAME_RM:
          serviceImpl.xaIsSameRM((com.openjproxy.grpc.XaIsSameRMRequest) request,
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.XaIsSameRMResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_LOB:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.createLob(
              (io.grpc.stub.StreamObserver<com.openjproxy.grpc.LobReference>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getConnectMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.ConnectionDetails,
              com.openjproxy.grpc.SessionInfo>(
                service, METHODID_CONNECT)))
        .addMethod(
          getExecuteUpdateMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.StatementRequest,
              com.openjproxy.grpc.OpResult>(
                service, METHODID_EXECUTE_UPDATE)))
        .addMethod(
          getExecuteQueryMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.openjproxy.grpc.StatementRequest,
              com.openjproxy.grpc.OpResult>(
                service, METHODID_EXECUTE_QUERY)))
        .addMethod(
          getFetchNextRowsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.ResultSetFetchRequest,
              com.openjproxy.grpc.OpResult>(
                service, METHODID_FETCH_NEXT_ROWS)))
        .addMethod(
          getCreateLobMethod(),
          io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
            new MethodHandlers<
              com.openjproxy.grpc.LobDataBlock,
              com.openjproxy.grpc.LobReference>(
                service, METHODID_CREATE_LOB)))
        .addMethod(
          getReadLobMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.openjproxy.grpc.ReadLobRequest,
              com.openjproxy.grpc.LobDataBlock>(
                service, METHODID_READ_LOB)))
        .addMethod(
          getTerminateSessionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.SessionInfo,
              com.openjproxy.grpc.SessionTerminationStatus>(
                service, METHODID_TERMINATE_SESSION)))
        .addMethod(
          getStartTransactionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.SessionInfo,
              com.openjproxy.grpc.SessionInfo>(
                service, METHODID_START_TRANSACTION)))
        .addMethod(
          getCommitTransactionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.SessionInfo,
              com.openjproxy.grpc.SessionInfo>(
                service, METHODID_COMMIT_TRANSACTION)))
        .addMethod(
          getRollbackTransactionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.SessionInfo,
              com.openjproxy.grpc.SessionInfo>(
                service, METHODID_ROLLBACK_TRANSACTION)))
        .addMethod(
          getCallResourceMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.CallResourceRequest,
              com.openjproxy.grpc.CallResourceResponse>(
                service, METHODID_CALL_RESOURCE)))
        .addMethod(
          getXaStartMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaStartRequest,
              com.openjproxy.grpc.XaResponse>(
                service, METHODID_XA_START)))
        .addMethod(
          getXaEndMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaEndRequest,
              com.openjproxy.grpc.XaResponse>(
                service, METHODID_XA_END)))
        .addMethod(
          getXaPrepareMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaPrepareRequest,
              com.openjproxy.grpc.XaPrepareResponse>(
                service, METHODID_XA_PREPARE)))
        .addMethod(
          getXaCommitMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaCommitRequest,
              com.openjproxy.grpc.XaResponse>(
                service, METHODID_XA_COMMIT)))
        .addMethod(
          getXaRollbackMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaRollbackRequest,
              com.openjproxy.grpc.XaResponse>(
                service, METHODID_XA_ROLLBACK)))
        .addMethod(
          getXaRecoverMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaRecoverRequest,
              com.openjproxy.grpc.XaRecoverResponse>(
                service, METHODID_XA_RECOVER)))
        .addMethod(
          getXaForgetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaForgetRequest,
              com.openjproxy.grpc.XaResponse>(
                service, METHODID_XA_FORGET)))
        .addMethod(
          getXaSetTransactionTimeoutMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaSetTransactionTimeoutRequest,
              com.openjproxy.grpc.XaSetTransactionTimeoutResponse>(
                service, METHODID_XA_SET_TRANSACTION_TIMEOUT)))
        .addMethod(
          getXaGetTransactionTimeoutMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaGetTransactionTimeoutRequest,
              com.openjproxy.grpc.XaGetTransactionTimeoutResponse>(
                service, METHODID_XA_GET_TRANSACTION_TIMEOUT)))
        .addMethod(
          getXaIsSameRMMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.openjproxy.grpc.XaIsSameRMRequest,
              com.openjproxy.grpc.XaIsSameRMResponse>(
                service, METHODID_XA_IS_SAME_RM)))
        .build();
  }

  private static abstract class StatementServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    StatementServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.openjproxy.grpc.StatementServiceOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("StatementService");
    }
  }

  private static final class StatementServiceFileDescriptorSupplier
      extends StatementServiceBaseDescriptorSupplier {
    StatementServiceFileDescriptorSupplier() {}
  }

  private static final class StatementServiceMethodDescriptorSupplier
      extends StatementServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    StatementServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (StatementServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new StatementServiceFileDescriptorSupplier())
              .addMethod(getConnectMethod())
              .addMethod(getExecuteUpdateMethod())
              .addMethod(getExecuteQueryMethod())
              .addMethod(getFetchNextRowsMethod())
              .addMethod(getCreateLobMethod())
              .addMethod(getReadLobMethod())
              .addMethod(getTerminateSessionMethod())
              .addMethod(getStartTransactionMethod())
              .addMethod(getCommitTransactionMethod())
              .addMethod(getRollbackTransactionMethod())
              .addMethod(getCallResourceMethod())
              .addMethod(getXaStartMethod())
              .addMethod(getXaEndMethod())
              .addMethod(getXaPrepareMethod())
              .addMethod(getXaCommitMethod())
              .addMethod(getXaRollbackMethod())
              .addMethod(getXaRecoverMethod())
              .addMethod(getXaForgetMethod())
              .addMethod(getXaSetTransactionTimeoutMethod())
              .addMethod(getXaGetTransactionTimeoutMethod())
              .addMethod(getXaIsSameRMMethod())
              .build();
        }
      }
    }
    return result;
  }
}
